from setuptools import setup

setup(
    name='dz-utils',
    version='0.0.1',
    description='Derek\'s commonly used helper functions',
    url='http://github.com/zhao1701/dz-utils',
    author='Derek Zhao',
    author_email='chong.zhao@columbia.edu',
    license='MIT',
    packages=['dzu'],
    zip_safe=False)
